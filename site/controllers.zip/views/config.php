<?php
$config['callback_url']         =   'http://www.stylior.com/home/facebook/?fbTrue=true'; //   /?fbTrue=true allow you to code process section.
$config['App_ID']      =   '158638837510402';
//$config['App_ID']      =   '991062177601636';
//$config['App_Secret']  =   '7815b8abbb6f427a745e9eb2a9fbf7ef'; 
$config['App_Secret']  =   '884224fec02533739671590565672065'; 
?>
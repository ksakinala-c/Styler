<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html>
    <head>
        <meta charset="UTF-8">
        <title>canvas editor</title>
		
		
		<script type="text/javascript" src="js/editor.js"></script>
		
		   <script src="js/ga.js" async="" type="text/javascript"></script><script type="text/javascript" src="js/fabric.js"></script> 
     <script type="text/javascript" src="js/jquery-1.js"></script> 
     <script type="text/javascript" src="js/jquery.js"></script> 
     <script type="text/javascript" src="js/fabric.js"></script> 
<script type="text/javascript" src="js/angular.js"></script> 
<script type="text/javascript" src="js/app_config.js"></script> 
<script type="text/javascript" src="js/bootstrap.js"></script> 
<script type="text/javascript" src="js/controller.js"></script> 

<script type="text/javascript" src="js/font_definitions.js"></script> 
<script type="text/javascript" src="js/jquery_002.js"></script> 
<script type="text/javascript" src="js/master.js"></script> 
<script type="text/javascript" src="js/paster.js"></script> 
<script type="text/javascript" src="js/prism.js"></script> 
<script type="text/javascript" src="js/utils.js"></script>
		
		
		  <script src="js/jquery.cropit.js"></script>
		
		
		
		

        <style>
		
         
            #info {
                position: absolute;
                top: 0px;
                width: 100%;
                padding: 5px;
                text-align:center;
            }


       

            .accord{
                width: 150px;
            }        

            #accordion {
                margin-top:10px;
                border:thin solid #cecece;   
                border-top:none;
                border-bottom:none;
            }

            #accordion div {
                background:white;
                //height:100px;
                //line-height:100px;
                width: 250px;
                display:none;
                border-bottom:thin solid #cecece;
                //padding-left:15px;
                padding: 15px 0px 15px 15px;
            }

        

            .first {
                border-top:thin solid #cecece;    
            }


            /*****************************************/



        </style>
    </head>
    <body onload="loadtexture()">

        <h1 style="text-align: center;">CANVAS EDITOR </h1>
   
        <div class="accord" style="float:left;">   
<!--
<button id="undo"><img src="img/undo.png" width="25px"/></button>
<button id="redo"><img src="img/redo.png" width="25px"/></button>-->


<button id="rasterize">Preview</button>
<a id="imageSaver" href="#" style="background-color:#e6e6e6; display:; text-align=; margin:0px ; "><button>Save image</button></a>
<button id="clear">Canvas clear</button>

<button id="canvas_size">Canvas Sizes</button>

<span id="canvas_sizes1" style="display:none">

<button id="2x3">2X3</button>
<button id="3x3">3X3</button>
<button id="1X3">1X3</button>
<button id="2X4">2X4</button>
<button id="3X1">3X1</button>
<button id="25X30">25X30</button>
<button id="40X60">40X60</button>


</span>



            <div id="accordion">
                
				
            
				
                
                <div id="">
	
				
				 <input id="picfile" name="filename" type="file"><br><br>
				
                  
<button id="" onclick="ZoomIn();"><img src="img/zoomin.png"  width="20px" /></button>
<button id="" onclick="ZoomOut();"><img src="img/zoomout.png"  width="20px" /></button><br><br>
<button id="del"><img src="img/delete.png"  width="20px" /></button><br><br>

<a href="#id01" id="startCrop" class="button"><img src="img/crop.png"  width="30px" /><b>Crop</b></a>
	
<br>
	<input type="color" id="textcolor" />Textcolor
	<button id="draw">Draw Text </button></br>
 
 <br>

<input type="color" id="colorChoice">Canvas backgroundcolor
</br>

<input type="text" id="addtext" /> <button id="addtext1">Add text</button>
</br>
   <span id="">
					  <label for="font-size" style="display:inline-block;background-color:#e6e6e6; padding:3px; border-radius:4px; ">Font Size:</label>
					  <select id="font-size" >
							<option selected="selected" value="10">10</option>
							<option value="15">15</option>
							<option value="20">20</option>
							<option value="25">25</option>
							<option value="30">30</option>
							<option value="35">35</option>
							<option value="40">40</option>
							<option value="45">45</option>
							<option value="50">50</option>
							<option value="60">60</option>
							<option value="70">70</option>
							<option value="80">80</option>
							<option value="90">90</option>
							<option value="100">100</option>
						</select>
		                        <br>
								
		    </span>

<input type="color" id="color" />Color


<br>
	    <span id="">
					  <label for="font-family" style="display:inline-block;background-color:#e6e6e6; padding:3px; border-radius:4px; ">Font family:</label>
					  <select id="font-family" class="btn-object-action" bind-value-to="fontFamily">
							<option selected="selected" value="arial">Arial</option>
							<option value="helvetica">Helvetica</option>
							<option value="myriad pro">Myriad Pro</option>
							<option value="delicious">Delicious</option>
							<option value="verdana">Verdana</option>
							<option value="georgia">Georgia</option>
							<option value="courier">Courier</option>
							<option value="comic sans ms">Comic Sans MS</option>
							<option value="impact">Impact</option>
							<option value="monaco">Monaco</option>
							<option value="optima">Optima</option>
							<option value="hoefler text">Hoefler Text</option>
							<option value="plaster">Plaster</option>
							<option value="engagement">Engagement</option>
						</select>
		                        <br>
								
		    </span>
			
			
			
			
			<!--<button id="ornt">Orientation</button>
			
			<span id="ornt1" style="display:none;">
			<button id="lftrtn"><img src="img/undo.png" /></button>
			<button id="rght"><img src="img/redo.png" /></button>
				<button id="verti"><img src="img/verti.png" width="20px" height="30px" /></button>
			</span>-->
<button id="sticker">Stickers</button>
			
			<span id="sticker1" style="display:none;">
			<img  class="img-polaroid"src="img/clip1.jpg" width="30px"/>
			<img  class="img-polaroid"src="img/clip2.jpg" width="30px"/>
			<img  class="img-polaroid"src="img/clip3.jpg" width="30px"/>
			<img  class="img-polaroid"src="img/clip4.jpg" width="30px"/>
			<img  class="img-polaroid"src="img/clip5.jpg" width="30px"/>
			<img  class="img-polaroid"src="img/clip6.jpg" width="30px"/>
			<img  class="img-polaroid"src="img/clip7.png" width="30px"/>
			<img  class="img-polaroid"src="img/clip9.png" width="30px"/>
			<img  class="img-polaroid"src="img/clip10.png" width="30px"/>
			
		</span>
			
		<button id="back">Background</button>
			
			<span id="back1" style="display:none;">
			<img  class="back2"src="back/img.jpg" width="30px"/>
			
			<img  class="back3"src="back/img2.jpg" width="30px"/>
			<img  class="back4"src="back/img3.jpg" width="30px"/>
			<img  class="back5"src="back/img4.jpg" width="30px"/>
			<img  class="back6"src="back/img5.jpg" width="30px"/>
			<img  class="back7"src="back/img6.jpg" width="30px"/>
			<img  class="back8"src="back/img7.jpg" width="30px"/>
			<img  class="back9"src="back/img8.jpg" width="30px"/>
				<img  class="back10"src="back/img9.jpg" width="30px"/>
					<img  class="back11"src="back/img10.jpg" width="30px"/>
						<img  class="back12"src="back/img11.jpg" width="30px"/>
							<img  class="back13"src="back/img12.jpg" width="30px"/>
		</span>	
		
		
		<button id="filters"> Filters</button>
		
			<span id="filters1" style="display:none;">
		<button id="gray1">Grayscale</button>
			<button id="sepia">sepia</button>
			<button id="Invert">Invert</button>
			<button id="Emboss">Emboss</button>
			<button id="contrast">contrast</button>
			
				</span>	
		
			<button id="shapes"> Shapes</button>
		
			<span id="shapes1" style="display:none;">
		<button id="circle">Circle</button>
			<button id="rectangle">Rectangle</button>
			
			<button id="line">Polygon</button>
			<button id="triangle">Triangle</button>
			
				</span>		
 </div>
							
				 




				  </div>

                
                
            




            </div>
        </div>




        <div id="right" style="position: ; left:300px;;float:right; margin:15px;">
		
		<canvas id="canvas"  width="700px" height="500px" style="border:2px groove #ccc; width:; height: " > </canvas>
		
		</div>



        <script src="http://ajax.googleapis.com/ajax/libs/jquery/1.11.2/jquery.min.js"></script>
   


        
        
       <style>
		
/* Add animation (Chrome, Safari, Opera) */
@-webkit-keyframes example {
    from {top:-100px;opacity: 0;}
    to {top:10px;opacity:1;}
}

/* Add animation (Standard syntax) */
@keyframes example {
    from {top:-100px;opacity: 0;}
    to {top:10px;opacity:1;}
}

/* The modal's background */
.modal {
  display: none;
  position: fixed;
  left: 0;
  top: 0;
  width: 100%;
  height: 100%;
  overflow: auto;
  background-color: rgb(0, 0, 0);
  background-color: rgba(0, 0, 0, 0.4);
  margin:0% auto;
}

/* Display the modal when targeted */
.modal:target {
  display: table;
  position: absolute;
}

/* The modal box */
.modal-dialog {
  display: table-cell;
  vertical-align: middle;
}

/* The modal's content */
.modal-dialog .modal-content {
//  margin:0% auto;
  background-color: ;
  position: relative;
  padding: 0;
  outline: 0;
  border: 1px #777 solid;
  text-align: justify;
  width:100%;
  height:600px;
  box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2), 0 6px 20px 0 rgba(0, 0, 0, 0.19);
 margin:0% 15% 15% 5%;

  
  /* Add animation */
  -webkit-animation-name: example; /* Chrome, Safari, Opera */
  -webkit-animation-duration: 0.5s; /* Chrome, Safari, Opera */
  animation-name: example;
  animation-duration: 0.5s;
}

/* The button used to close the modal */
.closebtn {
  text-decoration: none;
  float: right;
  font-size: 35px;
  font-weight: bold;
  color: #000;
}

.closebtn:hover,
.closebtn:focus {
  color: #000;
  text-decoration: none;
 cursor: pointer;
}

.container {
  padding: 2px 16px;
}

header {
  background-color: #;
  font-size: 25px;
  color: white;
}

footer {
  background-color: #;
  font-size: 20px;
  color: white;
}
</style><style>
 .cropit-image-preview {
        background-color: #f8f8f8;
        background-size: cover;
        border: 5px solid #ccc;
        border-radius: 3px;
        margin-top: 7px;
        width: 250px;
        height: 250px;
        cursor: move;
      }

      .cropit-image-background {
        opacity: .2;
        cursor: auto;
      }

      .image-size-label {
        margin-top: 10px;
      }

      input {
        /* Use relative position to prevent from being covered by image background */
        position: relative;
        z-index: 10;
        display: block;
      }

      .export {
        margin-top: 10px;
      }
</style>
		
				<div id="id01" class="modal" style="z-index:; background-color:;">


  <div class="modal-dialog">
    <div class="modal-content">
      <div class="image-editor">
     <input type="file" class="cropit-image-input">
      <!-- .cropit-image-preview-container is needed for background image to work -->
      <div class="cropit-image-preview-container">
        <div class="cropit-image-preview"></div>
      </div>
      <div class="image-size-label">
        Resize image
      </div>
      <input type="range" class="cropit-image-zoom-input">
      <button class="export">Export</button>
    </div>
    </div>
  </div>
  
</div>	

    </body>
	
	
	
	
	<script>
	
	
   $(function() {
        $('.image-editor').cropit({
			
          exportZoom: 1.25,
          imageBackground: true,
          imageBackgroundBorderWidth: 20,
          imageState: {
            src: 'http://lorempixel.com/500/400/',
          },
        });

        $('.export').click(function() {
			alert('zzz');
          var imageData = $('.image-editor').cropit('export');
          window.open(imageData);
        });
      });
	
	</script>
	<script>
	

  
  	var photoeditor = { };
  var canvas = new fabric.Canvas('canvas');

  
  
  
	
//image upload.....

	
	
	
	
document.getElementById('picfile').addEventListener("change", function(e) {
    var file = e.target.files[0];
    var reader = new FileReader();
    reader.onload = function(f) {
        var data = f.target.result;
        fabric.Image.fromURL(data, function(img) {
            var oImg = img.set({ left: 50, top: 100, angle: 00 });
            canvas.add(oImg).renderAll();
            canvas.setActiveObject(oImg);
        });
    };
    reader.readAsDataURL(file);
});
	
	
	
	
	

  //zoom in &zoom out...
function ZoomIn(){

    var SCALE_FACTOR = 1.2;
    var objects = canvas.getObjects();
    for (var i in objects) {
        var scaleX = objects[i].scaleX;
        var scaleY = objects[i].scaleY;
        var left = objects[i].left;
        var top = objects[i].top;
        var tempScaleX = scaleX * SCALE_FACTOR;
        var tempScaleY = scaleY * SCALE_FACTOR;
        var tempLeft = left * SCALE_FACTOR;
        var tempTop = top * SCALE_FACTOR;
        objects[i].scaleX = tempScaleX;
        objects[i].scaleY = tempScaleY;
        objects[i].left = tempLeft;
        objects[i].top = tempTop;
        objects[i].setCoords();
    	}
    canvas.renderAll();
	}

function ZoomOut(){
    var SCALE_FACTOR = 1.2;
    var objects = canvas.getObjects();
    for (var i in objects) {
        var scaleX = objects[i].scaleX;
        var scaleY = objects[i].scaleY;
        var left = objects[i].left;
        var top = objects[i].top;
        
        var tempScaleX = scaleX * (1/SCALE_FACTOR);
        var tempScaleY = scaleY * (1/SCALE_FACTOR);
        var tempLeft = left * (1/SCALE_FACTOR);
        var tempTop = top * (1/SCALE_FACTOR);
        
        objects[i].scaleX = tempScaleX;
        objects[i].scaleY = tempScaleY;
        objects[i].left = tempLeft;
        objects[i].top = tempTop;
        objects[i].setCoords();
    	}
    canvas.renderAll();
}

  
  
  
  
  //delete....

$(document).on('click', '#del' , function(){
    var canvas_objects = canvas._objects;
    if(canvas_objects.length !== 0){
     var last = canvas.getActiveObject();
     canvas.remove(last);
     canvase.renderAll();
    }   
});
  
  
  
  
  
  
  
  
  
  
  
	
            // display the first div by default.
            $("#accordion div").first().css('display', 'block');


// Get all the links.
            var link = $("#accordion a");

// On clicking of the links do something.
            link.on('click', function (e) {

                e.preventDefault();

                var a = $(this).attr("href");

                $(a).slideDown('fast');

                //$(a).slideToggle('fast');
                $("#accordion div").not(a).slideUp('slow');

            }
            );

			
			
			

			
			//crop....
/*var src = "http://fabricjs.com/lib/pug.jpg";
fabric.Image.fromURL('http://serio.piiym.net/CVBla/txtboard/thumb/1260285874089s.jpg', function (oImg) {
    canvas.add(oImg);
});
*/
 document.getElementById('picfile');
fabric.Image.fromURL('', function (oImg1) {
    oImg1.top = 20;
    oImg1.left = 30;
    canvas.add(oImg1);
});
canvas.renderAll();



$('#startCrop').on('click', function () {

	 var obj = canvas.getActiveObject();
		alert(obj);

    
  
});


		    $("#textcolor").change(function(){
canvas.freeDrawingBrush.color = $(this).val();
});
				
			
	$('#draw').on('click', function (event) {
		
		
canvas.isDrawingMode = true;
canvas.freeDrawingBrush.width = 5;


	})
	
			
			
		    $("#colorChoice").change(function(){
				
				var bgcolor= $(this).val();
				
  canvas.backgroundColor=bgcolor;
  
  
  canvas.renderAll();
  this.__canvases.push(canvas);
});
			
			 $("#color").change(function(){
				
				var fill= $(this).val();
				
 
  canvas.getActiveObject().set("fill", this.value);
           
  
  canvas.renderAll();
  
});
			
			
			
			
			
			$('#addtext1').on('click', function (event) {
				
		var text = document.getElementById("addtext").value;
	
var alignedRightText = new fabric.Text(text, {
  
 left:10,
 top:20,
 
});	
		canvas.add(alignedRightText);
			});		
			
			
		
			
			

			
		$("#font-family").change(function(){


		obj = canvas.getActiveObject();
		alert(obj);
		var family= $(this).val();
		alert(family);
		
		 canvas.getActiveObject().set("Fontfamily", "impact");
		 
	
		 
		  canvas.renderAll();
		  
	  
		  
		});
			
			
			$("#ornt").click(function(e){

$('#ornt1').css("display", "block");

});

$("#sticker").click(function(e){

$('#sticker1').css("display", "block");

});

$("#back").click(function(e){

$('#back1').css("display", "block");

});

$("#shapes").click(function(e){

$('#shapes1').css("display", "block");

});


$("#filters").click(function(e){

$('#filters1').css("display", "block");

});
  $("#lftrtn").click(function(){
  
    
    if( canvas._activeObject ) {
       var curAngle = canvas._activeObject.getAngle();
       canvas._activeObject.setAngle(curAngle-90); 
       canvas.renderAll();
    }
});
  
  
  $("#rght").click(function(){
  
    if( canvas._activeObject ) {
       var curAngle = canvas._activeObject.getAngle();
       canvas._activeObject.setAngle(curAngle+90); 
       canvas.renderAll();
    }
});
  
  
   $("#verti").click(function(){
  
    if( canvas._activeObject ) {
       var curAngle = canvas._activeObject.getAngle();
       canvas._activeObject.setAngle(curAngle+180); 
       canvas.renderAll();
    }
});
  
  

/*-----cliparts-----*/
  $(".img-polaroid").click(function(e){
        var el = e.target;
      
        var offset = 50;
          var left = fabric.util.getRandomInt(0 + offset, 200 - offset);
          var top = fabric.util.getRandomInt(0 + offset, 400 - offset);
          var angle = fabric.util.getRandomInt(-20, 40);
          var width = fabric.util.getRandomInt(30, 50);
          var opacity = (function(min, max){ return Math.random() * (max - min) + min; })(0.5, 0.8);
          
        fabric.Image.fromURL(el.src , function(image) {
              image.set({
                left: left,
                top: top,
                angle: 0,
                padding: 0,
                cornersize: 10,
                hasRotatingPoint:true,

              });

              //image.scale(getRandomNum(0.1, 0.25)).setCoords();
              canvas.add(image);
            });
      });

	  
	  
	    

	  
	  
	  
function undo() {
alert('hii');
    if (index <= 0) {
        index = 0;
        return;
    }
    
    if (refresh === true) {
        index--;
        refresh = false;
    }

    console.log('undo');

    index2 = index - 1;
    current = list[index2];
    current.setOptions(JSON.parse(state[index2]));

    index--;
    current.setCoords();
    canvas.renderAll();
    action = true;
}

function redo() {

    action = true;
    if (index >= state.length - 1) {
        return;
    }

    console.log('redo');

    index2 = index + 1;
    current = list[index2];
    current.setOptions(JSON.parse(state[index2]));

    index++;
    current.setCoords();
    canvas.renderAll();
}




$('#undo').click(function () {
    undo();
});
$('#redo').click(function () {
    redo();
});
			$("#canvas_size").click(function(e){

$('#canvas_sizes1').css("display", "block");

});

				

$("#2x3").click(function(){
$('canvas').css("width", "333");
 $('canvas').css("height", "500");

});


$("#3x3").click(function(){
$('canvas').css("width", "700");
 $('canvas').css("height", "500");

})



$("#1X3").click(function(){

$('canvas').css("width", "167");
 $('canvas').css("height", "500");

})



$("#2X4").click(function(){
$('canvas').css("width", "250");
 $('canvas').css("height", "500");

})


$("#3X1").click(function(){
$('canvas').css("width", "700");
 $('canvas').css("height", "234");

})


$("#25X30").click(function(){
$('canvas').css("width", "417");
 $('canvas').css("height", "500");

})

$("#40X60").click(function(){
$('canvas').css("width", "334");
 $('canvas').css("height", "500");

})









$("#font-size").change(function(){			


	var size= $(this).val();

	
	if(size==10){
	canvas.getActiveObject().set("fontSize", "10");	
	}
	
	else if(size==15){
	canvas.getActiveObject().set("fontSize", "15");	
	}
	
	else if(size==20){
	canvas.getActiveObject().set("fontSize", "20");	
	}
	
	else if(size==25){
	canvas.getActiveObject().set("fontSize", "25");	
	}
	else if(size==30){
	canvas.getActiveObject().set("fontSize", "30");	
	}
	else if(size==40){
	canvas.getActiveObject().set("fontSize", "40");	
	}
	else if(size==45){
	canvas.getActiveObject().set("fontSize", "45");	
	}
	else if(size==50){
	canvas.getActiveObject().set("fontSize", "50");	
	}
	else if(size==60){
	canvas.getActiveObject().set("fontSize", "60");	
	}
	else if(size==70){
	canvas.getActiveObject().set("fontSize", "70");	
	}
	else if(size==80){
	canvas.getActiveObject().set("fontSize", "80");	
	}
	else if(size==90){
	canvas.getActiveObject().set("fontSize", "90");	
	}
	
	 else if(size==100){
      canvas.getActiveObject().set("fontSize", "100");	
	}
    
	
 canvas.renderAll();  
	
});

  //back ground themes...
   
   
  $(".back2").click(function(){
	  
	  
        fabric.Image.fromURL('back/img.jpg', function(img) {
   img.set({width: canvas.width, height: canvas.height, originX: 'left', originY: 'top'});
   canvas.setBackgroundImage(img, canvas.renderAll.bind(canvas));
});
   });
  

          $(".back3").click(function(){
        fabric.Image.fromURL('back/img2.jpg', function(img) {
   img.set({width: canvas.width, height: canvas.height, originX: 'left', originY: 'top'});
   canvas.setBackgroundImage(img, canvas.renderAll.bind(canvas));
});
   }); 
   
   
 $(".back4").click(function(){
        fabric.Image.fromURL('back/img3.jpg', function(img) {
       
   img.set({width: canvas.width, height: canvas.height, originX: 'left', originY: 'top'});
   canvas.setBackgroundImage(img, canvas.renderAll.bind(canvas));
});
   }); 
   
   $(".back5").click(function(){
        fabric.Image.fromURL('back/img4.jpg', function(img) {
       
   img.set({width: canvas.width, height: canvas.height, originX: 'left', originY: 'top'});
   canvas.setBackgroundImage(img, canvas.renderAll.bind(canvas));
});
   }); 
   
    $(".back6").click(function(){
        fabric.Image.fromURL('back/img5.jpg', function(img) {
       
   img.set({width: canvas.width, height: canvas.height, originX: 'left', originY: 'top'});
   canvas.setBackgroundImage(img, canvas.renderAll.bind(canvas));
});
   }); 
   
    $(".back7").click(function(){
        fabric.Image.fromURL('back/img6.JPG', function(img) {
       
   img.set({width: canvas.width, height: canvas.height, originX: 'left', originY: 'top'});
   canvas.setBackgroundImage(img, canvas.renderAll.bind(canvas));
});
   }); 
   
    $(".back8").click(function(){
        fabric.Image.fromURL('back/img7.JPG', function(img) {
       
   img.set({width: canvas.width, height: canvas.height, originX: 'left', originY: 'top'});
   canvas.setBackgroundImage(img, canvas.renderAll.bind(canvas));
});
   }); 
   
    $(".back9").click(function(){
        fabric.Image.fromURL('back/img8.JPG', function(img) {
       
   img.set({width: canvas.width, height: canvas.height, originX: 'left', originY: 'top'});
   canvas.setBackgroundImage(img, canvas.renderAll.bind(canvas));
});
   }); 
   
    $(".back10").click(function(){
        fabric.Image.fromURL('back/img9.jpg', function(img) {
       
   img.set({width: canvas.width, height: canvas.height, originX: 'left', originY: 'top'});
   canvas.setBackgroundImage(img, canvas.renderAll.bind(canvas));
});
   }); 
   
    $(".back11").click(function(){
        fabric.Image.fromURL('back/img10.jpg', function(img) {
       
   img.set({width: canvas.width, height: canvas.height, originX: 'left', originY: 'top'});
   canvas.setBackgroundImage(img, canvas.renderAll.bind(canvas));
});
   }); 
   
    $(".back12").click(function(){
        fabric.Image.fromURL('back/img11.jpg', function(img) {
       
   img.set({width: canvas.width, height: canvas.height, originX: 'left', originY: 'top'});
   canvas.setBackgroundImage(img, canvas.renderAll.bind(canvas));
});
   }); 
   
    $(".back13").click(function(){
        fabric.Image.fromURL('back/img12.jpg', function(img) {
       
   img.set({width: canvas.width, height: canvas.height, originX: 'left', originY: 'top'});
   canvas.setBackgroundImage(img, canvas.renderAll.bind(canvas));
});
   }); 
   
    $("#clear").click(function(){

	
	canvas.clear();
	});

	
	
	
	
	$('#gray1').click(function() {
	
	$('#canvas').css("filter", "grayscale(100%)");
	
	});
	

$('#sepia').click(function() {
	
	$('#canvas').css("filter", "sepia(100%)");
	
	
	});
	
	
	
	
$('#Invert').click(function() {
	
	$('#canvas').css("filter", "invert(100%)");
	
	
	});
	
	
	$('#Emboss').click(function() {
	
	$('#canvas').css("filter", "blur(5px)");
	
	
	});
	
$('#contrast').click(function() {
	
	$('#canvas').css("filter", "contrast(200%)");
	
	
	});
	
	
	

$('#drop-shadow').click(function() {
	
	$('#canvas').css("filter", "drop-shadow(8px 8px 10px green)");
	
	
	});
	
	 
	
	
	$('#saturate').click(function() {
	
	$('#canvas').css("filter", "saturate(800%)");
	
	
	});
	
	/*-------Preview-------*/
$('#rasterize').click(function(){
  //alert('raster');
  
  
  if (!fabric.Canvas.supports('toDataURL')) {
      //alert('This browser doesn\'t provide means to serialize canvas to an image');
    }
    else {
      window.open(canvas.toDataURL('png'));
      
    }
  });
	


	$('#circle').click(function() {
	
	var circle = new fabric.Circle({
  radius: 50, fill: 'green', left: 100, top: 100
});
	
	canvas.add(circle);
	});
	
	
		$('#rectangle').click(function() {
	
var rect = new fabric.Rect({ width: 120, height: 80, fill: '#f55',left: 50, top: 50, opacity: 0.7 });
	
	canvas.add(rect);
	});
	
			$('#triangle').click(function() {
	
var triangle = new fabric.Triangle({
  width: 80, height:100, fill: 'blue', left: 150, top: 150
});
	
	canvas.add(triangle);
	});
	

	  
	  
	  			$('#line').click(function() {
	
   var path = new fabric.Path('M121.32,0L44.58,0C36.67,0,29.5,3.22,24.31,8.41\
c-5.19,5.19-8.41,12.37-8.41,20.28c0,15.82,12.87,28.69,28.69,28.69c0,0,4.4,\
0,7.48,0C36.66,72.78,8.4,101.04,8.4,101.04C2.98,106.45,0,113.66,0,121.32\
c0,7.66,2.98,14.87,8.4,20.29l0,0c5.42,5.42,12.62,8.4,20.28,8.4c7.66,0,14.87\
-2.98,20.29-8.4c0,0,28.26-28.25,43.66-43.66c0,3.08,0,7.48,0,7.48c0,15.82,\
12.87,28.69,28.69,28.69c7.66,0,14.87-2.99,20.29-8.4c5.42-5.42,8.4-12.62,8.4\
-20.28l0-76.74c0-7.66-2.98-14.87-8.4-20.29C136.19,2.98,128.98,0,121.32,0z');

canvas.add(path.set({ left: 100, top: 200, }));
    canvas.add(path);
	});
	  
	  
	  
	  //image save.....	
	var imageSaver = document.getElementById('imageSaver');
imageSaver.addEventListener('click', saveImage, false);

function saveImage(e) {
    this.href = canvas.toDataURL({
        format: 'png',
        quality: 0.8
    });
    this.download = 'image.png'
}

	  
	  
	
	</script>
	
</html>

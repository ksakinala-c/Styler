	

	//back ground themes...
   
   
  $(".back2").click(function(){
        fabric.Image.fromURL('back/img.jpg', function(img) {
   img.set({width: canvas.width, height: canvas.height, originX: 'left', originY: 'top'});
   canvas.setBackgroundImage(img, canvas.renderAll.bind(canvas));
});
   });
  

          $(".back3").click(function(){
        fabric.Image.fromURL('bg/images (2).jpg', function(img) {
   img.set({width: canvas.width, height: canvas.height, originX: 'left', originY: 'top'});
   canvas.setBackgroundImage(img, canvas.renderAll.bind(canvas));
});
   }); 
   
   
 $(".back4").click(function(){
        fabric.Image.fromURL('bg/images (3).jpg', function(img) {
       
   img.set({width: canvas.width, height: canvas.height, originX: 'left', originY: 'top'});
   canvas.setBackgroundImage(img, canvas.renderAll.bind(canvas));
});
   }); 
   
   $(".back5").click(function(){
        fabric.Image.fromURL('bg/images (4).jpg', function(img) {
       
   img.set({width: canvas.width, height: canvas.height, originX: 'left', originY: 'top'});
   canvas.setBackgroundImage(img, canvas.renderAll.bind(canvas));
});
   }); 
   
    $(".back6").click(function(){
        fabric.Image.fromURL('bg/images (5).jpg', function(img) {
       
   img.set({width: canvas.width, height: canvas.height, originX: 'left', originY: 'top'});
   canvas.setBackgroundImage(img, canvas.renderAll.bind(canvas));
});
   }); 
   
    $(".back7").click(function(){
        fabric.Image.fromURL('bg/images (6).jpg', function(img) {
       
   img.set({width: canvas.width, height: canvas.height, originX: 'left', originY: 'top'});
   canvas.setBackgroundImage(img, canvas.renderAll.bind(canvas));
});
   }); 
   
    $(".back8").click(function(){
        fabric.Image.fromURL('bg/images (7).jpg', function(img) {
       
   img.set({width: canvas.width, height: canvas.height, originX: 'left', originY: 'top'});
   canvas.setBackgroundImage(img, canvas.renderAll.bind(canvas));
});
   }); 
   
    $(".back9").click(function(){
        fabric.Image.fromURL('bg/images (8).jpg', function(img) {
       
   img.set({width: canvas.width, height: canvas.height, originX: 'left', originY: 'top'});
   canvas.setBackgroundImage(img, canvas.renderAll.bind(canvas));
});
   }); 
   
    $(".back10").click(function(){
        fabric.Image.fromURL('bg/images (11).jpg', function(img) {
       
   img.set({width: canvas.width, height: canvas.height, originX: 'left', originY: 'top'});
   canvas.setBackgroundImage(img, canvas.renderAll.bind(canvas));
});
   }); 
   
    $(".back11").click(function(){
        fabric.Image.fromURL('bg/images.jpg', function(img) {
       
   img.set({width: canvas.width, height: canvas.height, originX: 'left', originY: 'top'});
   canvas.setBackgroundImage(img, canvas.renderAll.bind(canvas));
});
   }); 
   
    $(".back12").click(function(){
        fabric.Image.fromURL('bg/Soft Summer Colors Mac Wallpapers Apple Themes-44727.jpeg', function(img) {
       
   img.set({width: canvas.width, height: canvas.height, originX: 'left', originY: 'top'});
   canvas.setBackgroundImage(img, canvas.renderAll.bind(canvas));
});
   }); 
   
    $(".back13").click(function(){
        fabric.Image.fromURL('bg/ss-w.jpg', function(img) {
       
   img.set({width: canvas.width, height: canvas.height, originX: 'left', originY: 'top'});
   canvas.setBackgroundImage(img, canvas.renderAll.bind(canvas));
});
   }); 
   
   





            
